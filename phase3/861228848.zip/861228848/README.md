I have code functionality working, but I do not have semantic erorr checking completed
